// Background service worker (required for MV3)
